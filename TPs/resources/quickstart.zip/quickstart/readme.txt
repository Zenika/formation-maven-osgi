Les commandes archectype:create ou archetype:generate ne marchent pas en mode offline.
Voici un quick produit

Le contenu est �quivalent � l'ex�cution de la commande suivante :
mvn archetype:create -DgroupId=com.zenika.formation -DartifactId=resanet-quickstart
